package icQ2.zuchoo;

import java.awt.Dimension;

import javax.swing.*;

public class Q2ChatConsole {
	
	static final JFrame mFrame = new JFrame("CHAT KONSOLE");
	static final JPanel mPanel = new JPanel();
	public static final JTextArea mTextArea = new JTextArea();
	public static final JScrollPane mScrollpane = new JScrollPane(mTextArea);
	
	public Q2ChatConsole() {
		mFrame.setVisible(true);
		mFrame.setSize(600, 500);
		mFrame.setResizable(false);
		mFrame.setLocationRelativeTo(null);
		mFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		mScrollpane.setPreferredSize(new Dimension(582,436));
		
		
		mPanel.add(mScrollpane);
		
		mFrame.add(mPanel);
		

		
	}
	
	public void druckeConsole(String inhalt) {
		mTextArea.append(inhalt+"\n");
	}

}
