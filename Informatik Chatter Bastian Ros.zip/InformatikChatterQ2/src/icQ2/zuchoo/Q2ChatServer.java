package icQ2.zuchoo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class Q2ChatServer {
	
	ServerSocket mSocket;
	Socket socket;
	
	PrintWriter output;
	BufferedReader input;
	
	static Q2ChatConsole console;
	
	static ArrayList<nutzer> benutzer = new ArrayList<nutzer>();
	
	public Q2ChatServer() {
		
		//SERVER SOCKET VERBINDUNG
		try {
			mSocket = new ServerSocket(1337);
			
			new Thread(new Runnable() {

				@Override
				public void run() {
					while(true) {
						try {
							socket = mSocket.accept();
							
							output = new PrintWriter(socket.getOutputStream(),true);
							input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
							
							nutzer nutzer = new nutzer(output,input);
							nutzer.userthread.start();
							
							benutzer.add(nutzer);
							
							console.druckeConsole(socket.getInetAddress() + " hat sich mit dem Server verbunden.");
							
						} catch (IOException e) {
							
							e.printStackTrace();
						}

					}
				
				
			}}).start();
			
			
			
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
		console = new Q2ChatConsole();
	}
	// SERVER SOCKET VERBINDUNG ENDE
	public static void main(String[] args) {
		new Q2ChatServer();
		
		console.druckeConsole("[SERVER GESTARTET]");
		
		
	}
	
	public static void sendeAnChat(String text) {
		for(int i = 0; i<benutzer.size(); i++) {
			nutzer nutzer = benutzer.get(i);
			if(nutzer == null || nutzer.output == null) {
				benutzer.remove(nutzer);
				
			}
			
			nutzer.output.println(text);
		}
	}


}
