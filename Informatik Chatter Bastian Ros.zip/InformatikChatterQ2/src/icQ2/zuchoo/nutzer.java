package icQ2.zuchoo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;

public class nutzer implements Runnable{
	
	public PrintWriter output;
	public BufferedReader input;
	public Thread userthread = new Thread(this);
	
	public nutzer(PrintWriter output, BufferedReader input) {
		this.output = output;
		this.input = input;
	}

	@SuppressWarnings("deprecation")
	@Override
	public void run() {
		while(true) {
			try {
				String text = input.readLine();
				Q2ChatServer.sendeAnChat(text);
				
			} catch (IOException e) {
				userthread.stop();
				e.printStackTrace();
			}
		}
		
	}
	

}
