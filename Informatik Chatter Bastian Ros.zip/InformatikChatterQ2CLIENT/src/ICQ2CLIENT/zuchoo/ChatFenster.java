package ICQ2CLIENT.zuchoo;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import javax.swing.text.DefaultCaret;

public class ChatFenster extends JFrame {
	private static final long serialVersionUID = 1L;
	
	static int breite = 820;
	static int hoehe = breite / 12 * 9;
	
	static final JPanel mPanel = new JPanel();
	static final JTextArea mTextArea = new JTextArea();
	static final JTextArea mUserArea = new JTextArea();
	static final JScrollPane mUserScroll = new JScrollPane(mUserArea);
	static final JScrollPane mScrollPane = new JScrollPane(mTextArea);
	static final JTextField mTextField = new JTextField();
	static final JButton mButton = new JButton("Abschicken");
	
	public ChatFenster() {
		this.setTitle("Informatik Q2 Chat");
		this.setSize(breite,hoehe);
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		
		mTextArea.setEditable(false);
		mScrollPane.setPreferredSize(new Dimension(breite - 32, hoehe - 100));
		mTextField.setPreferredSize(new Dimension(breite-32,20));
		
		mUserArea.setEditable(false);
		mUserScroll.setPreferredSize(new Dimension(breite / 6,hoehe-100));
		mUserArea.setPreferredSize(new Dimension(breite/6,hoehe-100));
		
		
		DefaultCaret caret = (DefaultCaret)mTextArea.getCaret();
		caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);
		
		
		
		mPanel.add(mScrollPane);
		
		mPanel.add(mScrollPane);
		mPanel.add(mUserArea);
		
		mPanel.add(mTextField);
		
		mPanel.add(mButton);
		
		this.add(mPanel);
		
		
		mButton.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				String text = mTextField.getText();
				Client.output.println("["+Client.nutzername+"]" + ": " + text);
				mTextField.setText("");
			}});
		
	}
	public static void ChatSchreiben(String inhalt) {
		mTextArea.append(inhalt+"\n");
	}
	public static void onlineUser() {
		mUserArea.append(Client.nutzername+"\n");
	}
}
